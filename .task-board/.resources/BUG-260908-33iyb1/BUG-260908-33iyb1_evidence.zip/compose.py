from pathlib import Path
import subprocess, tarfile, io
root=Path.cwd(); out=root/'.temp/BUG-260908-33iyb1'; dest=out/'composition'
base='b3422b05226253a17676b9b84c764071fe3dbe74'; pr='87451b53960ceabe88a01c44c287fee7f9ebf386'
dest.mkdir()
with tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','archive',pr]))) as tar:
    tar.extractall(dest,filter='data')
paths=set(subprocess.check_output(['git','diff','--name-only',base],text=True).splitlines())
paths.update(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines())
for name in sorted(paths):
    p=dest/name; p.parent.mkdir(parents=True,exist_ok=True)
    if name in ('README.md','LOGBOOK.md'):
        ancestor=subprocess.check_output(['git','show',base+':'+name])
        ours=(root/name).read_bytes()
        if name=='LOGBOOK.md':
            assert ours.startswith(ancestor)
            p.write_bytes(p.read_bytes()+ours[len(ancestor):])
        else:
            (out/'ancestor').write_bytes(ancestor);(out/'ours').write_bytes(ours)
            p.write_bytes(subprocess.check_output(['git','merge-file','-p',str(p),str(out/'ancestor'),str(out/'ours')]))
    else:
        p.write_bytes((root/name).read_bytes());p.chmod((root/name).stat().st_mode)
print('Composition: exact PR6 archive + checkpoint dc68c15 + uncommitted diagnostic delta')
print('\n'.join(sorted(paths)))
